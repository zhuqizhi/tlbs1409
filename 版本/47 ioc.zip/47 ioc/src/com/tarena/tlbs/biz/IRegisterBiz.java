package com.tarena.tlbs.biz;

import android.os.Handler;

import com.tarena.tlbs.model.UserEntity;

public interface IRegisterBiz {
public void register( Handler handler,UserEntity userEntity);
}
