package com.tarena.tlbs.biz.implJaxmpp2;

import com.tarena.tlbs.biz.ILoginBiz;
import com.tarena.tlbs.model.UserEntity;

public class LoginBiz implements ILoginBiz{

	@Override
	public void login(UserEntity userEntity) {
		// TODO Auto-generated method stub
		//��jaxmpp2ʵ��
	}

}
