package com.tarena.tlbs.biz;

import com.tarena.tlbs.model.UserEntity;

public interface ILoginBiz {
public void login(UserEntity userEntity);
}
